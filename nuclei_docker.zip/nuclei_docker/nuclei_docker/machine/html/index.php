<?php

	//Variable used to store the URL address that the user types in the browser
	$address = $_SERVER['REQUEST_URI'];

	//To check if the user's request includes a hidden tag called X-Debug-Token.
	//If this hidden tag is found, its value is saved in the variable
    if (isset($_SERVER['HTTP_X_DEBUG_TOKEN'])) {
    $secret_header = $_SERVER['HTTP_X_DEBUG_TOKEN'];
    } else {
    $secret_header = '';
    }

	//To check if the user is visiting the /admin/config page and has sent the secret header
	if ($address == '/admin/config' && $secret_header == 'debug') {
    
    // If both conditions are true, the flag is shown in the screen
    $flag_content = file_get_contents("/flag/flag_nuclei.txt");
    echo "<h1>Congratulations!</h1>";
    echo "The flag related to nuclei is: " . $flag_content;

    } else {
    
    // If any of them are wrong, a default message appears
    echo "<h1>[ NUCLEI MACHINE ]</h1>";
    echo "You do not have permission to see the secret.";
    }

?>

