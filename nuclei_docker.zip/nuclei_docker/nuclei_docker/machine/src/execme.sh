#! /bin/bash
# Run the initialization script (creates users, sets flag permissions)
/opt/src/first_init.sh;

# Delete first_init so it cannot be re-run manually
echo "#!/bin/bash" > /opt/src/first_init.sh;

# Start the Apache web server
service apache2 start

# Keep the container running forever
while [ 1 == 1 ]; do
	cat -
done;
