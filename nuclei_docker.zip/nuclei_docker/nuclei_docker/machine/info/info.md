# Nuclei

Something is hidden on this server.

Use Nuclei to scan it and find the flag.

**Hint:** sometimes servers respond differently depending on how you ask.

