#! /bin/bash
IP=${1:-127.0.0.1}
#Same port as the one that appears in the file .env and in docker-compose.yaml
PORT=${2:-42002}
nuclei -u "http://$IP:$PORT" -t $(find ~ -name "nuclei-debug-token.yaml")

# -u "http://$IP:$PORT": 
# It defines the target URL using the variables for IP and Port.

# -t nuclei-ctf-debug-token.yaml:
# It tells Nuclei to use a specific template to perform the attack.

# -silent:
# This is to show only the results, hiding all the extra technical information or noise.
