<?php
// Main page
echo "<h1>SYSTEM ONLINE</h1>";
echo "<p>Nothing to see here.</p>";
?>
