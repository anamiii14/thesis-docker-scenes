<?php

// Read the flag from the file mounted at /flag/flag_owaspzap.txt
$flag = file_get_contents("/flag/flag_owaspzap.txt");

// trim removes the new line that file_get_contents adds at the end of the file
// htmlspecialchars prevents the browser from reading < or > as HTML code
$flag = htmlspecialchars(trim($flag));

// Print the flag on screen
echo "<h1>You found it.</h1>";
echo "Flag: " . $flag;

?>