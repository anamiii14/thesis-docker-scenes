#! /bin/bash
# Update the available software packages so we can install the latest versions
apt update;
# Install the required software:
# - php: lets Apache run .php files (like our index.php)
# - sudo: allows running commands as administrator
# - curl: a tool to make HTTP requests
# - apache2: the web server that serves our page
apt install -y php sudo curl apache2
# Only the system can access this folder, not outsiders
chmod -R 770 /opt/src/
# Apache can read this folder and show it to anyone visiting the website
chmod -R 755 /var/www/html/
# Activate the Apache "headers" module
# Without this, Apache cannot add or modify HTTP headers
a2enmod headers
# Activate the rewrite module so .htaccess rules are processed
a2enmod rewrite
# Allow .htaccess files to work in the web folder
sed -i 's/AllowOverride None/AllowOverride All/g' /etc/apache2/apache2.conf

