#! /bin/bash
chown www-data:www-data /flag/flag_owaspzap.txt
# "chown" means "change owner". This line gives ownership of the flag file
# to "www-data", which is the user that Apache (the web server) runs as.
# This means only Apache can access the file, not other users.

chmod 400 /flag/flag_owaspzap.txt
# "chmod" means "change permissions". 400 means:
# - The owner (www-data) can only read the file
# - Nobody else can do anything with it (not read, not write, not execute)
# This prevents anyone from modifying or deleting the flag.

