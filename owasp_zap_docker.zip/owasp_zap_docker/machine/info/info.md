# OWASP ZAP

The server looks empty. But not everything is visible on screen.

Run OWASP ZAP against 'http://127.0.0.1:42003' and find the flag.

**Hint:** sometimes servers say more than they show.