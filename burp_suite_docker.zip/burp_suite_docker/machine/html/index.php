<?php

// Read the role from the cookie, default to "user" if not set
$role = $_COOKIE['role'] ?? 'user';

// If no cookie is set, send one with role=user
if (!isset($_COOKIE['role'])) {
    // setcookie sends a cookie to the browser
    setcookie('role', 'user');
}

if ($role === 'admin') {
    // Read the flag from the mounted file
    $flag = file_get_contents('/flag/flag_burpsuite.txt');
    // trim removes the newline at the end of the file
    // htmlspecialchars prevents the browser from reading < or > as HTML
    echo "<h1>Access granted.</h1>";
    echo "<p>Flag: " . htmlspecialchars(trim($flag)) . "</p>";
} else {
    echo "<h1>Access denied.</h1>";
    echo "<p>You do not have permission to view this page.</p>";
}

?>
