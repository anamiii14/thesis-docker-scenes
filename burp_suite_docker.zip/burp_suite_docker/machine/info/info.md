
# Burp Suite

The server restricts access based on your role.

Run Burp Suite against 'http://127.0.0.1:42004' and find the flag.

**Hint:** not everything is visible on screen. Try intercepting the request.